Bloggy::User.create(name: "admin", email:"nonmadden@gmail.com", password:"Arnon007", password_confirmation: "Arnon007")
