require 'domain_constraint'

Rails.application.routes.draw do

  constraints DomainConstraint.new(Rails.application.config.private_domain) do
    # root to: 'greetings#index'
    # mount Bloggy::Engine, at: '/blog'
  end

  constraints DomainConstraint.new(Rails.application.config.comunity_domain) do
    # root to: 'greetings#index'

  end
end
