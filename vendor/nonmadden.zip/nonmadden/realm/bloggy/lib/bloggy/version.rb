module Bloggy
  VERSION = "0.5.0"
end
