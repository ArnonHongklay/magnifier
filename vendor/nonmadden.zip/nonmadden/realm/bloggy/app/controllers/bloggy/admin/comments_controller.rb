class Bloggy::Admin::CommentsController < Bloggy::Admin::BaseController
  def show
  end
end
