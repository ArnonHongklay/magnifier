Dummy::Application.routes.draw do
  mount Bloggy::Engine, at: "/bloggy"
end
