FactoryGirl.define do
  factory :tag, class: Bloggy::Tag do
    name "Rails"
  end
end
