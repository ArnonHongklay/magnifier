Bloggy::User.create!({name: "Bloggy", email: "bloggy@example.com", password: "bloggy", password_confirmation: "bloggy"})
