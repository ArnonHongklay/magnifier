class GreetingsController < ApplicationController
  layout 'greetings'

  def index
  end
end
